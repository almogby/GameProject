from Live import welcome, load_game

print(welcome("Almog"))
load_game()
